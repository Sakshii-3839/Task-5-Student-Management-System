package studentmanagement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

class Student {
    String rollNumber, name, course;

    Student(String rollNumber, String name, String course) {
        this.rollNumber = rollNumber;
        this.name = name;
        this.course = course;
    }

    public String toString() {
        return rollNumber + " - " + name + " (" + course + ")";
    }
}
public class StudentManagementSystem {
	private static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Student Management System");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField rollField = new JTextField(10);
        JTextField nameField = new JTextField(10);
        JTextField courseField = new JTextField(10);

        JButton addBtn = new JButton("Add Student");
        JButton viewBtn = new JButton("View Students");
        JButton deleteBtn = new JButton("Delete by Roll No");
        JTextArea outputArea = new JTextArea(10, 40);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        frame.add(new JLabel("Roll No:"));
        frame.add(rollField);
        frame.add(new JLabel("Name:"));
        frame.add(nameField);
        frame.add(new JLabel("Course:"));
        frame.add(courseField);
        frame.add(addBtn);
        frame.add(viewBtn);
        frame.add(deleteBtn);
        frame.add(scrollPane);

        // Add student
        addBtn.addActionListener(e -> {
            String roll = rollField.getText();
            String name = nameField.getText();
            String course = courseField.getText();
            if (!roll.isEmpty() && !name.isEmpty() && !course.isEmpty()) {
                students.add(new Student(roll, name, course));
                outputArea.setText("Student added.\n");
                rollField.setText("");
                nameField.setText("");
                courseField.setText("");
            } else {
                outputArea.setText("Please fill all fields.\n");
            }
        });

        // View students
        viewBtn.addActionListener(e -> {
            outputArea.setText("");
            for (Student s : students) {
                outputArea.append(s + "\n");
            }
        });

        // Delete student
        deleteBtn.addActionListener(e -> {
            String roll = rollField.getText();
            students.removeIf(s -> s.rollNumber.equals(roll));
            outputArea.setText("Student with roll no " + roll + " deleted (if existed).\n");
        });

        frame.setVisible(true);
    }

}
