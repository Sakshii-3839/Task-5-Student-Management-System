/**
 * 
 */
/**
 * 
 */
module StudentManagement {
	requires java.desktop;
}